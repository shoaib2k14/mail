<?php

require_once "vendor/autoload.php";
$mail = new PHPMailer\PHPMailer\PHPMailer();
//Enable SMTP debugging.
$mail->SMTPDebug = 3;                           
//Set PHPMailer to use SMTP.
$mail->isSMTP();        
//Set SMTP host name                      
$mail->Host = "195.232.244.151";
//Set this to true if SMTP host requires authentication to send email
//$mail->SMTPAuth = true;                      
//Provide username and password
//$mail->Username = "name@gmail.com";             
//$mail->Password = "super_secret_password";                       
//If SMTP requires TLS encryption then set it
$mail->SMTPSecure = "tls";                       
//Set TCP port to connect to
$mail->Port = 25;                    
$mail->From = "name@gmail.com";
$mail->FromName = "Full Name";
$mail->addAddress("sraafey2k14@gmail.com", "Recepient Name");
$mail->isHTML(true);
$mail->Subject = "Subject Text";
$mail->Body = "<i>Mail body in HTML</i>";
$mail->AltBody = "This is the plain text version of the email content";
if(!$mail->send())
{
echo "Mailer Error: " . $mail->ErrorInfo;
}
else
{
echo "Message has been sent successfully";
}
?>