<?php

error_reporting(E_ALL);

$htmlbody = "PFA";
$subject = "Email testing";


require('phpmailer/PHPMailerAutoload.php');

$mail = new PHPMailer;
$mail->isSMTP();
$mail->SMTPDebug = 0;
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;
$mail->Username = "sraafey2k14@gmail.com";
$mail->Password = "hvpmuodnbtriltvv";
$mail->setFrom("sraafey2k14@gmail.com");
$mail->addAddress('komalnaikwadi77@gmail.com');

//$mail->addAttachment($file);
$mail->Subject = $subject;
$mail->msgHTML($htmlbody);
if (!$mail->send()) {
echo "Mailer Error: ".$mail->ErrorInfo;
}
else
{
    echo "Leads Sent Successfully";
}
